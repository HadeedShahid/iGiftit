// import styles from './SavedPatyment.module.css'
import CardItem from './CardItem';
const SavedPayment=()=>{
    return(
        <div>
            <CardItem title={'Jazzcash - Shawaze Ahmer'} detail={'+92 123 4567893'}
            links={[{name:'Remove'}]}
            ></CardItem>
        </div>
    );
};
export default SavedPayment