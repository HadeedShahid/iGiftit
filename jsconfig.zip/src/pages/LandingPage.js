import Authenticate from "Components/Authenticate/Authenticate";
const LandingPage=()=>{
    return (<Authenticate></Authenticate>);
};
export default LandingPage;